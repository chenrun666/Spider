url = "http://v9-dy.ixigua.com/a9a4117bc59556d96cfecb37b26e6500/5c35bdf0/video/m/220a111178e79884ac1bd6134d72246ba3811612eefe000061d7220a1a21/?rc=Mzg2eDl1PGVuajMzN2kzM0ApQHRAbzo4MzQ0OjgzNDU3OTw0PDNAKXUpQGczdylAZmh1eXExZnNoaGRmOzRAcHBtYDRpbGNtXy0tNi0vc3MtbyNvI0AwLTAzLS4tLTIvLi0tLi9pOmItbyM6YC1vI3BiZnJoXitqdDojLy5e"

a = url.split("rc=")[-1]
print(a)